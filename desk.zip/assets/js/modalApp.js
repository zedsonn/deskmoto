$(function(){

    //Modal Delivery App
    $("#delivery").on("click", function(){
            window.scrollTo(0, 0);

        $(".box-modal-app").animate({
            height: '100%',
            backgroundColor: "rgba(0,0,0,.2)",
        },700);

        $(".box-modal-app").css({
            zIndex: '350',
        });

        setTimeout(function(){
            $("#deliveryApp").animate({
                opacity: 1,
            },700);
            $("#deliveryApp").css({
                zIndex: '400',
            });
        }, 680);

    });

    $(".close-modal-app").on('click', function(){
        $("#address").val(""); 
        $("#deliveryApp").animate({
            opacity: 0,
        },700);
        setTimeout(function(){
            
        $(".box-modal-app").animate({
            height: '0',
            backgroundColor: "rgba(0,0,0,.2)",
            zIndex: "0",

        },700);
            $("#deliveryApp").css({
                zIndex: '-100',
                display: 'none',
            });
        }, 680);
    });

    //Cadastrar Empresa

    $("#cadastroEmpresa").on("click", function(){
        $(".box-input, .box-entrega, .box-btn-entrega").animate({
            opacity: "0",
        },680);
        
        setTimeout(function(){
            $("#boxCadastro").removeClass("box-cadastro-off");
            $("#boxCadastro".addClass("box-cadastro"));
            $(".box-cadastro").animate({
                opacity: "1",
            },680);
        },682)
    });


   
   });